import studentRoutes from "./students/index.js";
import teacherRoutes from "./teachers/index.js";

const allRoutes = [studentRoutes, teacherRoutes];

export default allRoutes;
